import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-domain3',
  templateUrl: './domain3.page.html',
  styleUrls: ['./domain3.page.scss'],
})
export class Domain3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
